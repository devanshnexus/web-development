
<?php $__env->startSection('dashContent'); ?>
<form action="<?php echo e(Request::segment(2)=='add'?route('booking.save'):route('booking.update',['id'=>Request::segment(2)])); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="container">
      <?php if(Auth::user()->user_type == 2): ?>
      <div class="mb-3 w-50">
          <label for="user_name" class="form-label">User Name</label>
          <select class="form-select" name="user_name" aria-label="Default select example">
            <option selected>Select User</option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php echo e(isset($booking->user_id) && $booking->user_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>
      <?php else: ?>
        <input type="hidden" name="user_name" value="<?php echo e(isset($booking->user_id)?$booking->user_id:Auth::user()->id); ?>">
      
      <?php endif; ?>
      <div class="mb-3 w-50">
          <label for="booking_name" class="form-label">Booking Name</label>
          <input type="text" class="form-control" id="booking_name" name="booking_name" placeholder="Booking Name" value="<?php echo e(isset($booking->name)?$booking->name:''); ?>">
      </div>
      <div class="mb-3 w-50">
          <label for="booking_on" class="form-label">Booking on</label>
          <input type="date" class="form-control" id="booking_on" name="booking_on" placeholder="Booking Date" value="<?php echo e(isset($booking->booking_datetime)?$booking->booking_datetime:''); ?>">            
      </div>
      <div class="mb-3 w-50">
        <label for="booking_status" class="form-label">Booking status</label>
        <select class="form-select" name="booking_status" aria-label="Default select example">
          <option selected>Set Status</option>
          <option value="1" <?php echo e(isset($booking->status) && $booking->status == 1 ? 'selected' : ''); ?> >Booked</option>
          <option value="2" <?php echo e(isset($booking->status) && $booking->status == 2 ? 'selected' : ''); ?> >Booking cancelled</option>
          <option value="3" <?php echo e(isset($booking->status) && $booking->status == 3 ? 'selected' : ''); ?> >Booking Fulfilled</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary"><?php echo e(Request::segment(2)=='add'?'Save':'Update'); ?></button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDashboard.Layout.adminBaseView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classes\Laravel BMS\booking_management_system\resources\views/AdminDashboard/Bookings/addEdit.blade.php ENDPATH**/ ?>