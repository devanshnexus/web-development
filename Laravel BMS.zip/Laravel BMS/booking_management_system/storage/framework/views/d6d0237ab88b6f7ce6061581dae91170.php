
<?php $__env->startSection('dashContent'); ?>
<form action="<?php echo e(route('user.profile.save')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="container">    
    <div class="mb-3 w-50">
      <label for="name" class="form-label">Name</label>
      <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e(isset($data->name)?$data->name:''); ?>">
    </div>
    <div class="mb-3 w-50">
      <label for="email" class="form-label">Email Address</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Email"value="<?php echo e(isset($data->email)?$data->email:''); ?>">
    </div>
    <div class="mb-3 w-50">
      <label for="phone_no" class="form-label">Phone Number</label>
      <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone Number"value="<?php echo e(isset($data->phone_no)?$data->phone_no:''); ?>">
    </div>  
    <button type="submit" class="btn btn-primary">Update</button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDashboard.Layout.adminBaseView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classes\Laravel BMS\booking_management_system\resources\views/AdminDashboard/Profile/index.blade.php ENDPATH**/ ?>