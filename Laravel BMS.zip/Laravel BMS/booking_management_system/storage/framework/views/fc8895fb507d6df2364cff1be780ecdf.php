
<?php $__env->startSection('dashContent'); ?>
    <div class="container">
        <a href="<?php echo e(route('user.add')); ?>" class="btn btn-primary mb-2 float-end">Create New User</a>
        <table class="table table-light table-striped table-hover">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">User Name</th>
                <th scope="col">User Email</th>                
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>             
                <?php $i =1; ?>    
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td><?php echo e(@$user->name); ?></td>
                    <td><?php echo e(@$user->email); ?></td>
                   
                    <td><div class="dropdown">
                        <span class="bi bi-list"></span>
                        <div class="dropdown-content">
                            <a href="<?php echo e(route('user.edit',['id'=>$user->id])); ?>"><i class="bi bi-pencil-square"></i> Edit</a>                     
                            <a href="<?php echo e(route('user.view.delete',['id'=>$user->id])); ?>"><i class="bi bi-trash"></i> Delete</a>
                        </div>
                    </div>
                    </td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDashboard.Layout.adminBaseView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classes\Laravel BMS\booking_management_system\resources\views/AdminDashboard/Users/index.blade.php ENDPATH**/ ?>