
<?php $__env->startSection('dashContent'); ?>
    <div class="container">
        <a href="<?php echo e(route('webpage.add')); ?>" class="btn btn-primary mb-2 float-end">Create New Page</a>
        <table class="table table-light table-striped table-hover">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Page Name</th>
                <th scope="col">Page Slug</th>
                
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>             
                <?php $i =1; ?>    
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td><?php echo e(@$page->name); ?></td>
                    <td><?php echo e(@$page->slug); ?></td>
                   
                    <td><div class="dropdown">
                        <span class="bi bi-list"></span>
                        <div class="dropdown-content">
                            <a href="<?php echo e(route('webpage.edit',['id'=>$page->id])); ?>"><i class="bi bi-pencil-square"></i> Edit</a>                     
                            <a href="<?php echo e(route('webpage.view.delete',['id'=>$page->id])); ?>"><i class="bi bi-trash"></i> Delete</a>
                        </div>
                    </div>
                    </td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDashboard.Layout.adminBaseView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classes\Laravel BMS\booking_management_system\resources\views/AdminDashboard/Webpage/index.blade.php ENDPATH**/ ?>