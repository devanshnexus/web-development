
<?php $__env->startSection('dashContent'); ?>
<form action="<?php echo e(Request::segment(2)=='add'?route('user.save'):route('user.update',['id'=>Request::segment(2)])); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="container">    
    <div class="mb-3 w-50">
      <label for="name" class="form-label">Name</label>
      <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e(isset($data->name)?$data->name:''); ?>">
    </div>
    <div class="mb-3 w-50">
      <label for="email" class="form-label">Email Address</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Email"value="<?php echo e(isset($data->email)?$data->email:''); ?>">
    </div>
    <div class="mb-3 w-50">
      <label for="phone_no" class="form-label">Phone Number</label>
      <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone Number"value="<?php echo e(isset($data->phone_no)?$data->phone_no:''); ?>">
    </div>
    
    <div class="mb-3 w-50">
      <label for="booking_status" class="form-label">User type</label>
      <select class="form-select" name="user_type" aria-label="Default select example">
        <option selected>Set Status</option>
        <option value="1" <?php echo e(isset($data->user_type) && $data->user_type == 1 ? 'selected' : ''); ?> >Admin</option>
        <option value="2" <?php echo e(isset($data->user_type) && $data->user_type == 2 ? 'selected' : ''); ?> >User</option>
        
      </select>
    </div>
    <button type="submit" class="btn btn-primary"><?php echo e(Request::segment(2)=='add'?'Save':'Update'); ?></button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDashboard.Layout.adminBaseView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classes\Laravel BMS\booking_management_system\resources\views/AdminDashboard/Users/addEdit.blade.php ENDPATH**/ ?>