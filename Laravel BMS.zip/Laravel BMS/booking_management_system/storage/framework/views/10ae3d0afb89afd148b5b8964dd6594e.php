
<?php $__env->startSection('dashContent'); ?>
<form action="<?php echo e(route('booking.delete',['id'=>Request::segment(3)])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3 w-50">
        <h6 for="usertype"  class="form-label">Are you Sure you want to delete this Booking?</h6>
    </div>
    <div class="mb-3 w-50">
        <button type="submit" class="btn btn-danger">Delete</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('UserDashboard.Layout.userBaseView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\classes\Laravel BMS\booking_management_system\resources\views/UserDashboard/Bookings/delete.blade.php ENDPATH**/ ?>