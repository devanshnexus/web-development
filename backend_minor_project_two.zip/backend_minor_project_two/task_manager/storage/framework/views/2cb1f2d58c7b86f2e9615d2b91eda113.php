Dear <?php echo e($data->task_owner); ?>,<br><br>

The Task <?php echo e($data->task_description); ?>,<br><br> <?php echo e($data->task_eta==0?"has been added for you":"Has been Marked as Completed"); ?><br><br>

<?php if($data->task_eta == 0): ?>
Kindlt Complete it within <?php echo e($data -> task_eta); ?>,<br><br>
<?php endif; ?>

Thank You<?php /**PATH C:\xampp\htdocs\classes\backend_minor_project_two\task_manager\resources\views/email/notification.blade.php ENDPATH**/ ?>